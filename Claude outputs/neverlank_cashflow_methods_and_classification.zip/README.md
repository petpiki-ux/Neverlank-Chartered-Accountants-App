# Continuous statement tables, Cash Flow method choice, and Company classification

## What you asked for

After reviewing the Word document from the previous update ("N8100_Financial_Statements_2026 1.docx"), you flagged:

> "These are financial statements after update they dont show any notes and are not aligned to suggested templates also put criteria for grouping companies as per zimbabwean context this choice will be made on finalisation sheet after all adjustments have been made let the preparer make a selection choice and then financial statements are prepared accordingly"

You then sent a second, correctly-generated file ("N8100_Financial_Statements_2026 2.docx") to check against, and while you were reviewing it, sent three more specific requests:

> "Make the balance sheet continuous table without breaks and Balance sheet and Income statement, and Cashflow figures with detailed notes must put note reference number in the accounts"

> "The Cashflow statement must be detailed one either direct or indirect method let the preparer make a choice"

This round addresses all of it.

## The first file you sent

That file had no Notes to the Financial Statements section at all - which is exactly what the app looked like *before* the previous update was applied. The second file you sent confirmed the update was live and working correctly (full Notes section, correct figures). Nothing needed fixing there; it was a timing issue, not a bug.

## What changed this round

### 1. The Statement of Financial Position is now ONE continuous table in the Word document

Previously, the downloaded Word document built five separate tables for the Statement of Financial Position (non-current assets, current assets, equity, non-current liabilities, current liabilities), each with its own heading and a paragraph gap in between - different from the Finalisation tab on screen, which has always shown it as one continuous table. The Word document now matches: one table, running straight from "Non-current assets" down to "Total equity and liabilities", with bold section and subtotal rows in between, and no breaks.

### 2. Note reference numbers now appear on the Statement of Profit or Loss, Statement of Financial Position, and Cash Flow Statement - in both places

The on-screen Statement of Financial Position and Statement of Profit or Loss already had a Note column from the previous round; the Word document's versions of those two statements did not, so it's added there too. More significantly, the Cash Flow Statement's investing and financing lines (property, plant and equipment; shares issued; borrowings; dividends paid) now carry Note numbers as well - on screen and in the Word document. A line that combines more than one account category, like "Proceeds from shares issued" (share capital + share premium), shows every note number involved, comma-separated (e.g. "8, 9"), so nothing is left unreferenced. The Cash Flow Statement's operating activities section is left without note numbers, since those lines are a reconciliation/receipts-and-payments presentation rather than individual account balances - the same reasoning already applied to that section previously.

### 3. Cash Flow Statement: indirect or direct method, your choice

The Cash Flow Statement can now be prepared under either method, selected per engagement on the Finalisation tab (defaults to indirect, so nothing changes unless you pick otherwise):

- **Indirect method** (unchanged): reconciles from profit before tax through non-cash adjustments and working capital movements.
- **Direct method** (new): shows cash received from customers, other income received, and cash paid to suppliers and employees directly.

Whichever you choose, investing activities, financing activities, and every subtotal from "Cash generated from operations" down to the closing cash balance are **identical** - this isn't a coincidence, the direct-method figures are deliberately built to net to the exact same "Cash generated from operations" total as the indirect method, term for term. This matters because IAS 7 requires both methods to reconcile to the same net cash from operating activities; the two were never allowed to disagree, and now they can't.

### 4. Company classification (Finalisation tab, decided after adjustments are final)

Before touching this, I looked into how Zimbabwean law actually draws the line between reporting frameworks, since getting this wrong in an audit tool has real consequences. What I found: the Companies and Other Business Entities Act sets no numeric revenue/asset/employee threshold for choosing Full IFRS vs IFRS for SMEs - it just requires "generally accepted accounting practice" as recognised by PAAB. PAAB itself (Pronouncement 2/2016) draws that line on **public accountability** instead. Based on your confirmed answer ("Both, PIE test drives the framework, SME Act band is just recorded"), the Finalisation tab now has:

- **A Public Interest Entity checklist**: listed on a securities exchange; bank/building society/microfinance institution; insurer; asset manager/collective investment scheme; pension fund open to a wide range of employees; registered medical aid society; or issues debt/equity instruments to the public. Ticking any one of these shows a "Public Interest Entity" indicator and recommends Full IFRS; leaving all unticked shows "Not a Public Interest Entity" and recommends IFRS for SMEs (Full IFRS can still be chosen). This is guidance only - you always make the final call in the Financial reporting framework dropdown right below it, exactly as you asked ("let the preparer make a selection choice").
- **Sector and size band (Small and Medium Enterprises Act)**: a separate dropdown pair recording which of the Act's Micro/Small/Medium/Large bands the entity falls into, by sector. This is Zimbabwean law's own "small/medium/large" classification, but it's a business-development/tax classification, not an accounting-standards one - a Large non-PIE company remains perfectly entitled to use IFRS for SMEs. It's recorded for your own client/engagement records and does not drive which framework or statements are prepared, per your answer.

## What was tested

A new automated test (`smoke_test27`, 59 checks) covers: the direct and indirect Cash Flow methods reconciling to the exact same operating cash flow total from the same trial balance; Cash Flow note cross-referencing, including a line that spans two categories; the Word document's Statement of Financial Position rendering as one continuous table; and the full Company classification workflow (ticking a Public Interest Entity box, saving, and seeing the recommendation and framework selector update; recording an SME Act sector/band; switching Cash Flow methods and seeing the Word document follow). The full existing regression suite (`smoke_test16` through `smoke_test26`, 622 checks) was re-run and still passes in full.

**Total: 681 checks, 0 failed.**

## How to apply this update

Same as previous updates - [GitHub Desktop](https://desktop.github.com/) (or plain `git`), repository already cloned.

**Option A - copy the files (simplest):**

1. Unzip this package.
2. Copy everything inside `files/` into your repository, keeping the same folder structure (`templates/engagements/detail.html` goes into your `templates/engagements/` folder, the rest into the repository root).
3. In GitHub Desktop, review the changed files, commit (the message below is ready to paste, or write your own), and push.

**Option B - apply the patch with git:**

```
git am 0001-Continuous-statement-tables-with-Note-cross-referenc.patch
git push
```

## Files changed

- `financials.py` - Cash Flow Statement direct-method calculation (algebraically tied to the indirect method), note cross-referencing extended to investing/financing rows including combined-category rows.
- `models.py` - new `CASH_FLOW_METHODS`, `PIE_CRITERIA`, `SME_ACT_SECTORS`/`SME_ACT_SIZE_BANDS`; new Engagement fields (`cash_flow_method`, the seven PIE checklist booleans, `sme_sector`, `sme_size_band`) and the `is_public_interest_entity`/`recommended_reporting_framework` properties.
- `app.py` - lightweight auto-migration for the new Engagement columns.
- `engagements.py` - wires the new selectors/checklist into the Finalisation tab and the save action, passes `cash_flow_method` through to statement building.
- `templates/engagements/detail.html` - the Company classification card, the Cash Flow method selector, and the Note column on the Cash Flow Statement table.
- `workpapers.py` - the Statement of Financial Position as one continuous table, the Note column added to the Word document's SFP/P&L tables, and the Cash Flow Statement rebuilt as a detailed table matching the on-screen view (with the chosen method and Note column).
