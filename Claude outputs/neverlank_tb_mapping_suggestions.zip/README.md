# Suggested account mappings, confirmed in one batch

This answers what you asked: can the app assist with mapping and let you
just confirm, and is Analytical Review already fully automatic with
flagging built in.

## Analytical Review - already there

Once a trial balance is mapped, "Generate from Trial Balance" already
pulls every P&L line and balance-sheet total automatically - no typing.
Every line already gets its variance % computed and is flagged as
significant automatically once it crosses a threshold (10% by default,
adjustable per engagement on the Analytical Review tab). No code change
was needed here - it's been live since the last round. The one thing
intentionally *not* automated is explaining *why* a flagged fluctuation
happened - that's the auditor's judgment call, not something the app
should decide for you.

## Account Mapping - now suggests, you confirm in one batch

Previously, Account Mapping setup was one account at a time: pick a
category from a blank dropdown, click "Map", repeat - 142 times for
your real file. That's fixed:

- Every unmapped account's dropdown is now **pre-filled with a
  suggested category**, guessed from the account's name (e.g. "Vault -
  Head Office" -> Cash and cash equivalents, "Trade Creditors" -> Trade
  and other payables), marked **(suggested)** so it's clear it's a
  starting point, not a decision already made. Nothing is saved to the
  database from the suggestion alone.
- You scan down the list, fix any that look wrong (or leave a row as
  "Unmapped" to decide later), then click **Confirm mappings** once -
  one submit for every row you've reviewed, instead of one submit per
  account.
- Confirming a mapping still does what it always did: it's remembered
  for this client, so the same account name auto-maps on every future
  period's import.

The suggestions come from keyword matching on the account name (not
AI/LLM), as you asked for - instant, free, no external API key needed,
and fully predictable. The ordering was built carefully so specific
phrases win over generic ones - e.g. "Bank Overdraft" suggests a
short-term borrowing rather than cash, "Bank Charges" suggests a
finance cost rather than cash, and "Cost of Sales" suggests cost of
sales rather than being caught by the word "sales" and suggested as
revenue.

## Tested against your real file - an honest result, not a rosy one

I ran this against the same 142-account file from the last round:
**83 accounts (58%) got a correct-looking suggestion** automatically -
cash, payables, receivables, standard expense and income lines.

The other **59 correctly stayed unmapped** rather than being guessed at
- and they're not random misses, they cluster in a way that makes
sense once you see it: this looks like a microfinance/lending
institution's chart of accounts (Individual/SME/Group/Agricultural
Loans, Impairment Loss Allowance, Penalty Income), mobile-money
accounts (ECOCASH), and Zimbabwean statutory lines (PAYE, NSSA, IMMT).
Keyword matching genuinely can't tell "Individual Loans" is a
receivable (an asset - money lent out to customers) rather than a
payable by name alone, so it leaves it for you rather than guessing
wrong - which matters more here than in most businesses, since getting
a lender's loan book onto the wrong side of the balance sheet would be
a real error, not a cosmetic one.

If this is in fact a lending/microfinance client (or several of your
clients share this chart of accounts), it's worth telling me - I can
add a second, more specific rule set tailored to a loan book (loans
recognized as receivables, impairment allowances as a contra-asset,
penalty/interest income correctly split, etc.) so those 59 shrink
towards zero too, the same way this round's generic rules were built.

## Testing

New `smoke_test25_tb_mapping_suggestions.py` (33 checks): the keyword
suggester's ordering (confirms "Bank Overdraft"/"Bank Charges"/"Cost of
Sales" aren't misclassified by a more generic keyword), the Trial
Balance tab pre-filling suggestions correctly, the batch confirm route
mapping selected rows, skipping rows left "Unmapped", never touching
an already-mapped line even if a stray field for it is posted, and
upserting the reusable per-client mapping on confirm.

Full regression across all ten smoke test files:
**573 checks passed, 0 failed.**

## How to apply this update

Apply this round's changes, either by copying the three files under
`files/` over your existing ones (`engagements.py`, `financials.py`,
`templates/engagements/detail.html`), or with:
`git am 0001-Suggest-IAS-1-categories-for-unmapped-trial-balance-.patch`

No database changes in this round - nothing new was added to the schema.
