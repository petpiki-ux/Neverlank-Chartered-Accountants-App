"""Smoke test for this round's Account Mapping setup improvement:

  1. financials.suggest_fs_category() - a best-effort keyword suggestion
     for an unmapped account's IAS 1 category, from its name alone, with
     deliberate ordering so specific phrases ("bank overdraft", "bank
     charges", "cost of sales") aren't shadowed by more generic ones
     ("bank", "sales") that would otherwise misclassify them.
  2. The Account Mapping setup screen pre-fills each unmapped account's
     dropdown with its suggestion (marked "(suggested)") instead of a
     blank "Unmapped", without writing anything to the database on its
     own - only the render changes.
  3. The new batch "Confirm mappings" action
     (engagements.confirm_suggested_tb_mappings): maps every row whose
     dropdown was left at a real category, skips any row left as
     "Unmapped" (no error, no guess), upserts the reusable COAMapping for
     each one confirmed, and never touches a line that was already
     mapped even if a stray form field for it is posted.

Uses a temporary DATA_DIR (isolated sqlite db) - no real network or API
key needed to run this.
"""
import os
import sys
import tempfile
from datetime import date

TMP_DATA_DIR = tempfile.mkdtemp(prefix="neverlank_smoke25_")
os.environ["DATA_DIR"] = TMP_DATA_DIR
os.environ.pop("ANTHROPIC_API_KEY", None)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

passed = 0
failed = 0


def check(label, condition):
    global passed, failed
    if condition:
        passed += 1
    else:
        failed += 1
        print(f"FAIL: {label}")


from extensions import db
from models import User, Client, Engagement, TrialBalance, TrialBalanceLine, COAMapping
import financials as fin

import flask
import flask.testing
_orig_open = flask.testing.FlaskClient.open


def _open_with_fresh_login_cache(self, *args, **kwargs):
    try:
        flask.g.pop("_login_user", None)
    except RuntimeError:
        pass
    return _orig_open(self, *args, **kwargs)


flask.testing.FlaskClient.open = _open_with_fresh_login_cache

from app import app
app.config["WTF_CSRF_ENABLED"] = False

# -------------------------------------------------- Part 1: suggest_fs_category unit tests

check("'Bank Overdraft' suggests short_term_borrowings, not cash", fin.suggest_fs_category("Bank Overdraft") == "short_term_borrowings")
check("'CABS Bank Charges' suggests finance_costs, not cash", fin.suggest_fs_category("CABS Bank Charges") == "finance_costs")
check("'Vault - Head Office' suggests cash", fin.suggest_fs_category("Vault - Head Office") == "cash")
check("'CABS Current Account' suggests cash", fin.suggest_fs_category("CABS Current Account") == "cash")
check("'Cost of Sales' suggests cost_of_sales, not revenue", fin.suggest_fs_category("Cost of Sales") == "cost_of_sales")
check("'Sales Revenue' suggests revenue", fin.suggest_fs_category("Sales Revenue") == "revenue")
check("'Staff Salaries' suggests admin_expenses", fin.suggest_fs_category("Staff Salaries") == "admin_expenses")
check("'Trade Creditors' suggests trade_payables", fin.suggest_fs_category("Trade Creditors") == "trade_payables")
check("'Trade Debtors' suggests trade_receivables", fin.suggest_fs_category("Trade Debtors") == "trade_receivables")
check("'Motor Vehicles' suggests ppe", fin.suggest_fs_category("Motor Vehicles") == "ppe")
check("'Share Capital' suggests share_capital", fin.suggest_fs_category("Share Capital") == "share_capital")
check("a completely generic/unrecognizable name returns None (no guess)", fin.suggest_fs_category("XZQ Ledger Code 44821") is None)
check("blank name returns None", fin.suggest_fs_category("") is None and fin.suggest_fs_category(None) is None)

with app.app_context():
    admin = User(username="admin25", name="Test Admin 25", email="admin25@test.local", role="admin")
    admin.set_password("password123")
    db.session.add(admin)
    db.session.commit()

    client_row = Client(name="Mapping Test Co (Pvt) Ltd", industry="Retail")
    db.session.add(client_row)
    db.session.commit()

    engagement = Engagement(
        client_id=client_row.id, title="FY2026 Audit", type="Audit",
        acceptance_required=False, partner_id=admin.id, period_end=date(2026, 12, 31),
    )
    db.session.add(engagement)
    db.session.commit()
    engagement_id = engagement.id

    tc = app.test_client()
    login_resp = tc.post("/auth/login", data={"username": "admin25", "password": "password123"}, follow_redirects=True)
    check("login succeeds", login_resp.status_code == 200)

    tb = TrialBalance(engagement_id=engagement_id, source="upload")
    db.session.add(tb)
    db.session.commit()
    lines = [
        TrialBalanceLine(trial_balance_id=tb.id, account_code="100", account_name="Vault - Head Office", current_debit=6000, current_credit=0, prior_debit=5000, prior_credit=0, fs_category=None),
        TrialBalanceLine(trial_balance_id=tb.id, account_code="200", account_name="Trade Creditors", current_debit=0, current_credit=3000, prior_debit=0, prior_credit=2500, fs_category=None),
        TrialBalanceLine(trial_balance_id=tb.id, account_code="300", account_name="XZQ Ledger Code 44821", current_debit=100, current_credit=0, prior_debit=0, prior_credit=0, fs_category=None),
        TrialBalanceLine(trial_balance_id=tb.id, account_code="400", account_name="Already Mapped Account", current_debit=50, current_credit=0, prior_debit=0, prior_credit=0, fs_category="excluded"),
    ]
    db.session.add_all(lines)
    db.session.commit()
    db.session.refresh(tb)
    vault_line = next(l for l in tb.lines if l.account_code == "100")
    creditors_line = next(l for l in tb.lines if l.account_code == "200")
    unknown_line = next(l for l in tb.lines if l.account_code == "300")
    already_mapped_line = next(l for l in tb.lines if l.account_code == "400")

    # -------------------------------------------------- Part 2: the Trial Balance tab pre-fills suggestions

    tb_tab = tc.get(f"/engagements/{engagement_id}?tab=trial_balance")
    check("trial balance tab renders", tb_tab.status_code == 200)
    body = tb_tab.data.decode()
    check("Vault row's select has the cash option pre-selected as suggested", f'<option value="cash" selected>Cash and cash equivalents (suggested)</option>' in body)
    check("Creditors row's select has trade_payables pre-selected as suggested", f'<option value="trade_payables" selected>Trade and other payables (suggested)</option>' in body)
    check("unrecognizable account's select defaults to blank Unmapped (no guess)", '<option value="" selected>Unmapped</option>' in body)
    check("explanatory copy about suggestions being a starting point is shown", "pre-filled with a suggested category" in body)
    check("bulk Confirm mappings button present", "Confirm mappings</button>" in body)
    check("no per-row Map button anymore (replaced by the batch action)", "Map</button>" not in body)
    check("already-mapped account is not in the Account Mapping setup section's unmapped rows", "Already Mapped Account" not in body.split("Account Mapping setup")[1].split("Add an account manually")[0])

    # -------------------------------------------------- Part 3: confirming the batch

    confirm_resp = tc.post(
        f"/engagements/{engagement_id}/trial-balance/confirm-suggested-mappings",
        data={
            f"fs_category__{vault_line.id}": "cash",           # accepted the suggestion as-is
            f"fs_category__{creditors_line.id}": "trade_payables",  # accepted the suggestion as-is
            f"fs_category__{unknown_line.id}": "",              # left as Unmapped - no suggestion existed
            f"fs_category__{already_mapped_line.id}": "revenue",  # stray field for an already-mapped line - must be ignored
        },
        follow_redirects=True,
    )
    check("confirm-suggested-mappings request succeeds", confirm_resp.status_code == 200)
    confirm_body = confirm_resp.data.decode()
    check("success flash names how many were mapped and how many remain", "2 account(s) mapped" in confirm_body and "1 still need a category" in confirm_body)

    db.session.refresh(tb)
    check("Vault account is now mapped to cash", vault_line.fs_category == "cash")
    check("Trade Creditors account is now mapped to trade_payables", creditors_line.fs_category == "trade_payables")
    check("unrecognizable account correctly remains unmapped (was skipped, not guessed)", unknown_line.fs_category is None)
    check("already-mapped account's category is untouched by the stray posted field", already_mapped_line.fs_category == "excluded")
    check("trial balance now has exactly 1 unmapped account left", tb.unmapped_count == 1)

    vault_mapping = COAMapping.query.filter_by(client_id=client_row.id, account_name="vault - head office").first()
    check("confirming a mapping also upserts the reusable COAMapping for this client", vault_mapping is not None and vault_mapping.fs_category == "cash")

    # -------------------------------------------------- Part 4: confirming with everything left Unmapped is a no-op, not an error

    noop_resp = tc.post(
        f"/engagements/{engagement_id}/trial-balance/confirm-suggested-mappings",
        data={f"fs_category__{unknown_line.id}": ""},
        follow_redirects=True,
    )
    check("submitting with nothing selected still returns 200", noop_resp.status_code == 200)
    check("an explanatory info flash is shown rather than a silent no-op", "No mappings were confirmed" in noop_resp.data.decode())
    db.session.refresh(tb)
    check("unmapped count is unchanged after the no-op confirm", tb.unmapped_count == 1)

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
