# Continuous statement tables, Cash Flow method choice, and Company classification (with SME Act auto-suggestion)

This is the combined package for the two updates delivered today after your review of the generated Financial Statements Word document - previously sent as two separate zips, now combined into one so you only have to apply one thing.

## What you asked for

Reviewing the generated Word document, then while reviewing the corrected version, you asked for several things in sequence:

> "Make the balance sheet continuous table without breaks and Balance sheet and Income statement, and Cashflow figures with detailed notes must put note reference number in the accounts"

> "The Cashflow statement must be detailed one either direct or indirect method let the preparer make a choice"

> "...put criteria for grouping companies as per zimbabwean context this choice will be made on finalisation sheet after all adjustments have been made let the preparer make a selection choice and then financial statements are prepared accordingly"

...and then, after I'd built a preparer-self-declared version of that last item (having been unable to source a reliable numeric schedule myself), you sent a screenshot of the general Zimbabwean Small and Medium Enterprises Act size thresholds and asked me to auto-classify from entered figures instead.

## What changed

### 1. The Statement of Financial Position is now ONE continuous table in the Word document

Previously the downloaded Word document built five separate tables for the Statement of Financial Position, each with its own heading and a paragraph gap in between - different from the Finalisation tab on screen, which has always shown it as one continuous table. The Word document now matches: one table, running straight from "Non-current assets" down to "Total equity and liabilities," with bold section and subtotal rows in between, and no breaks.

### 2. Note reference numbers on the Statement of Profit or Loss, Statement of Financial Position, and Cash Flow Statement - on screen and in the Word document

The Word document's Statement of Financial Position and Statement of Profit or Loss now carry the same Note column the on-screen tables already had. More significantly, the Cash Flow Statement's investing and financing lines (property, plant and equipment; shares issued; borrowings; dividends paid) now cross-reference their Note number(s) too - a line that combines more than one account category, like "Proceeds from shares issued" (share capital + share premium), shows every note number involved, comma-separated (e.g. "8, 9"). The Cash Flow Statement's operating activities section is left without note numbers, since those lines are a reconciliation/receipts-and-payments presentation rather than individual account balances.

### 3. Cash Flow Statement: indirect or direct method, your choice

Selected per engagement on the Finalisation tab, defaulting to indirect so nothing changes unless you pick otherwise:

- **Indirect method** (unchanged): reconciles from profit before tax through non-cash adjustments and working capital movements.
- **Direct method** (new): shows cash received from customers, other income received, and cash paid to suppliers and employees directly.

Whichever you choose, investing activities, financing activities, and every subtotal from "Cash generated from operations" down to the closing cash balance are **identical** - the direct-method figures are deliberately built to net to the exact same "Cash generated from operations" total as the indirect method, term for term, so the two can never disagree (as IAS 7 requires).

### 4. Company classification (Finalisation tab, decided after adjustments are final)

Before building this, I looked into how Zimbabwean law actually draws the line between reporting frameworks. What I found: the Companies and Other Business Entities Act sets no numeric revenue/asset/employee threshold for choosing Full IFRS vs IFRS for SMEs - it just requires "generally accepted accounting practice" as recognised by PAAB, and PAAB itself (Pronouncement 2/2016) draws that line on **public accountability** instead. The Finalisation tab now has:

- **A Public Interest Entity checklist**: listed on a securities exchange; bank/building society/microfinance institution; insurer; asset manager/collective investment scheme; pension fund open to a wide range of employees; registered medical aid society; or issues debt/equity instruments to the public. Ticking any one shows a "Public Interest Entity" indicator and recommends Full IFRS; leaving all unticked recommends IFRS for SMEs. This is guidance only - you always make the final call in the Financial reporting framework dropdown right below it.
- **Sector, and size band (Small and Medium Enterprises Act)**: a separate, informational classification (Zimbabwean law's own "small/medium/large," but a business-development/tax classification, not an accounting-standards one - a Large non-PIE company remains entitled to use IFRS for SMEs). It does not drive which framework or statements are prepared.

### 5. SME Act size band: auto-suggested from entered figures

Using the general thresholds table you supplied (staff headcount, max annual turnover, max gross assets excl. real estate, for Micro/Small/Medium, anything larger being Large), the Company classification card now has three input fields - **staff headcount**, **annual turnover**, and **gross assets excl. real estate** - and shows a computed suggestion ("Suggested band based on the figures above: Small") next to the existing Size band dropdown, alongside a collapsible reference table of the thresholds themselves. The dropdown is unchanged and still has the final say - entering figures only changes the suggestion shown, never the stored classification on its own.

Two judgment calls worth being upfront about: your table gave headcount as ranges ("6 to 30/40," "31 to 75/100") since the Act's real schedule varies slightly by sector and yours was a general summary - I used the higher number of each pair as the ceiling, so a company isn't understated into a smaller band than its own sector might allow. And an entity only qualifies for a band if it meets **every** one of that band's thresholds; exceeding even one bumps it to the next band up. Both are flagged in the app itself (the reference table's own caption) as a general approximation, not the final word on a genuinely borderline case.

## What was tested

Two new automated tests: `smoke_test27` (71 checks) covers the direct/indirect Cash Flow tie-out, Cash Flow note cross-referencing (including a combined-category line), the Word document's continuous Statement of Financial Position table, the full Company classification workflow, and the SME Act auto-suggestion at each threshold boundary. The full pre-existing regression suite (`smoke_test16` through `smoke_test26`, 622 checks) was re-run and still passes in full.

**Total: 693 checks, 0 failed.**

## How to apply this update

Same as previous updates - [GitHub Desktop](https://desktop.github.com/) (or plain `git`), repository already cloned.

**Option A - copy the files (simplest):**

1. Unzip this package.
2. Copy everything inside `files/` into your repository, keeping the same folder structure (`templates/engagements/detail.html` goes into your `templates/engagements/` folder, the rest into the repository root). These are the final, combined versions of each file - you don't need to apply anything in between.
3. In GitHub Desktop, review the changed files, commit, and push.

**Option B - apply both patches with git, in order:**

```
git am 0001-Continuous-statement-tables-with-Note-cross-referenc.patch
git am 0002-Auto-suggest-a-Small-and-Medium-Enterprises-Act-size.patch
git push
```

This applies both commits with their full messages and authorship already attached, one after the other.

## Files changed

- `financials.py` - Cash Flow Statement direct-method calculation, note cross-referencing extended to investing/financing rows, `classify_sme_size()` and its thresholds.
- `models.py` - `CASH_FLOW_METHODS`, `PIE_CRITERIA`, `SME_ACT_SECTORS`/`SME_ACT_SIZE_BANDS`; new Engagement fields (`cash_flow_method`, the seven PIE checklist booleans, `sme_sector`, `sme_size_band`, `sme_annual_turnover`, `sme_gross_assets`, `sme_staff_headcount`) and the `is_public_interest_entity`/`recommended_reporting_framework` properties.
- `app.py` - lightweight auto-migration for all the new Engagement columns.
- `engagements.py` - wires every new selector/checklist/field into the Finalisation tab and the save action, passes `cash_flow_method` through to statement building, computes the SME Act suggestion for display.
- `templates/engagements/detail.html` - the Company classification card (PIE checklist, SME Act fields and reference table), the Cash Flow method selector, and the Note column on the Cash Flow Statement table.
- `workpapers.py` - the Statement of Financial Position as one continuous table, the Note column added to the Word document's SFP/P&L tables, and the Cash Flow Statement rebuilt as a detailed table matching the on-screen view.
