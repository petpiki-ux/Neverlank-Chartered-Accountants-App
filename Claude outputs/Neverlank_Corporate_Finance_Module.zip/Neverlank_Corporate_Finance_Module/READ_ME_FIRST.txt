Corporate Finance & Business Advisory module (replaces Consulting)
===================================================================
Copy everything in this folder over the matching files in your app folder
(Neverlank-Chartered-Accountants-App), keeping the sub-folders. Then push with GitHub Desktop and deploy.

NEW files:      cf_engine.py cf_tools.py cf_excel.py cf_report.py cf_pdf.py corporate_finance.py templates/corpfin/*.html
CHANGED files:  models.py app.py seed.py doc_templates.py templates/base.html static/css/style.css
(models.py / app.py / seed.py / doc_templates.py were last copied from your folder earlier today; if you edited them
 since, tell me before overwriting.)

On first start the app migrates existing data automatically:
 - "Consulting" engagements, checklists, document templates and tasks become Corporate Finance & Business Advisory
 - the Tax / CGT checklist moves to Tax Advisory; BI & IT tasks move to a new "IT & Business Intelligence" category
Access: new permission "Use Corporate Finance & Business Advisory models" (Supervisor, Partner, Admin by default;
adjustable under Access Rights). Only Partner/Admin can finalise or reopen a model.
