"""Payroll Management - covers BOTH sides the firm asked for: Neverlank's
own staff payroll, and a payroll SERVICE the firm offers to clients (a
client's own employees, processed by this firm). See models.py for the
full design note above PayrollEmployee/PayrollPeriod/Payslip, and
payroll_calc.py for the tax engine itself.

Access is gated on the "manage_payroll" permission everywhere in this
blueprint (defaults to Partner/Admin only, since salary data is sensitive)
- there is no partial/read-only tier in this first version.
"""
from datetime import datetime, date, timedelta

from flask import Blueprint, render_template, redirect, url_for, request, flash, abort, send_file
from flask_login import login_required, current_user

from extensions import db
from models import visible_clients
from client_scope import guard_blueprint, restrict_to_visible_clients
from models import (
    Client, User, PayrollTaxSettings, PayrollTaxBand, PayrollEmployee,
    PayrollPeriod, Payslip, PayslipItem, TimeSheet,
    PAYROLL_SCOPES, PAYROLL_PAY_FREQUENCIES, PAYROLL_PERIOD_STATUSES,
    PAYSLIP_ITEM_CATEGORIES, PAYROLL_TAX_CAVEAT,
    user_has_permission,
)
import payroll_calc
import payroll_documents
import leave_calc

payroll_bp = Blueprint("payroll", __name__, url_prefix="/payroll")


def _ensure_payroll_access():
    if not user_has_permission(current_user, "manage_payroll"):
        abort(403)


def can_see_internal_payroll(user=None):
    """Neverlank's OWN staff payroll (scope "internal": employees, periods and payslips) is visible to the Managing Partner only. The
    firm has one Managing Partner and signs in as an Admin, so the rule is: Admin role. Partners, Supervisors and Staff are locked out
    even when they have the "manage_payroll" permission (which they need for the client payroll service), and even for their own
    payslip. Client payroll (scope "client") is unaffected."""
    user = user or current_user
    return bool(getattr(user, "is_authenticated", False) and user.role == "admin")


def _ensure_scope_access(scope):
    """403 for anything that is not client payroll unless the user may see the firm's own staff payroll."""
    if scope != "client" and not can_see_internal_payroll():
        abort(403, description="Neverlank's own staff payroll and payslips can only be seen by the Managing Partner.")


def _ensure_period_access(period):
    _ensure_scope_access(period.scope)


def _ensure_payslip_access(payslip):
    _ensure_scope_access(payslip.period.scope if payslip.period else "internal")


def _get_tax_settings():
    settings = PayrollTaxSettings.query.get(1)
    if not settings:
        settings = PayrollTaxSettings(id=1, source_notes=PAYROLL_TAX_CAVEAT)
        db.session.add(settings)
        db.session.commit()
    return settings


def _parse_date(value):
    if not value:
        return None
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except ValueError:
        return None


def _parse_float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _timesheet_summary_for(employee, period):
    """Links Time Sheets (hr.py) to internal payroll: for an 'internal'
    PayrollEmployee linked to a User account, the Approved timesheets whose
    week overlaps this payroll period's date range, with the usual
    regular/overtime split (see models.TimeSheet). Read-only information -
    there's no house policy in this app for an overtime pay rate, so this
    surfaces the hours for the preparer to price via an Allowance line item
    themselves rather than guessing a rate. Returns None when there's
    nothing to link (a client-scope employee, no linked User, or the
    period has no date range yet)."""
    if employee.scope != "internal" or not employee.user_id or not period.period_start or not period.period_end:
        return None
    sheets = (
        TimeSheet.query.filter_by(user_id=employee.user_id, status="Approved")
        .filter(TimeSheet.week_start <= period.period_end)
        .order_by(TimeSheet.week_start)
        .all()
    )
    in_range = [s for s in sheets if (s.week_start + timedelta(days=6)) >= period.period_start]
    return {
        "sheets": in_range,
        "regular_hours": round(sum(s.regular_hours for s in in_range), 2),
        "overtime_hours": round(sum(s.overtime_hours for s in in_range), 2),
        "total_hours": round(sum(s.total_hours for s in in_range), 2),
    }


# Staff and Supervisors only reach payroll data of clients they work on.
guard_blueprint(payroll_bp, {
    "employee_id": lambda v: getattr(PayrollEmployee.query.get(v), "client_id", None),
    "period_id": lambda v: getattr(PayrollPeriod.query.get(v), "client_id", None),
    "payslip_id": lambda v: getattr(getattr(Payslip.query.get(v), "period", None), "client_id", None),
    "item_id": lambda v: getattr(getattr(getattr(PayslipItem.query.get(v), "payslip", None), "period", None), "client_id", None),
})


# --------------------------------------------------------------- Dashboard

@payroll_bp.route("/")
@login_required
def dashboard():
    _ensure_payroll_access()
    show_internal = can_see_internal_payroll()
    internal_periods = (
        PayrollPeriod.query.filter_by(scope="internal")
        .order_by(PayrollPeriod.period_start.desc().nullslast(), PayrollPeriod.id.desc())
        .limit(8).all()
    ) if show_internal else []
    client_periods = (
        restrict_to_visible_clients(PayrollPeriod.query.filter_by(scope="client"), PayrollPeriod.client_id)
        .order_by(PayrollPeriod.period_start.desc().nullslast(), PayrollPeriod.id.desc())
        .limit(8).all()
    )
    internal_employee_count = PayrollEmployee.query.filter_by(scope="internal", is_active=True).count() if show_internal else 0
    client_employee_count = restrict_to_visible_clients(
        PayrollEmployee.query.filter_by(scope="client", is_active=True), PayrollEmployee.client_id).count()
    clients_with_payroll = restrict_to_visible_clients(
        db.session.query(Client)
        .join(PayrollEmployee, PayrollEmployee.client_id == Client.id)
        .filter(PayrollEmployee.scope == "client"), Client.id,
    ).distinct().order_by(Client.name).all()
    settings = _get_tax_settings()
    # Per-frequency, not just "does ANY band exist" - see PayrollTaxBand's
    # docstring: ZIMRA publishes a genuinely different table per pay
    # frequency, so having Monthly bands says nothing about whether
    # Fortnightly/Weekly are configured.
    frequencies_missing_bands = [
        f for f in PAYROLL_PAY_FREQUENCIES if PayrollTaxBand.query.filter_by(frequency=f).count() == 0
    ]
    bands_missing = bool(frequencies_missing_bands)
    return render_template(
        "payroll/dashboard.html",
        internal_periods=internal_periods, client_periods=client_periods, show_internal=show_internal,
        internal_employee_count=internal_employee_count, client_employee_count=client_employee_count,
        clients_with_payroll=clients_with_payroll, settings=settings, bands_missing=bands_missing,
        frequencies_missing_bands=frequencies_missing_bands,
        caveat=PAYROLL_TAX_CAVEAT,
    )


# --------------------------------------------------------------- Tax Settings

@payroll_bp.route("/tax-settings", methods=["GET", "POST"])
@login_required
def tax_settings():
    _ensure_payroll_access()
    settings = _get_tax_settings()

    if request.method == "POST":
        settings.currency = request.form.get("currency", "USD").strip() or "USD"
        settings.aids_levy_pct = _parse_float(request.form.get("aids_levy_pct"), settings.aids_levy_pct or 0.0)
        settings.nssa_employee_pct = _parse_float(request.form.get("nssa_employee_pct"), 0.0)
        settings.nssa_employer_pct = _parse_float(request.form.get("nssa_employer_pct"), 0.0)
        ceiling = request.form.get("nssa_insurable_ceiling", "").strip()
        settings.nssa_insurable_ceiling = _parse_float(ceiling) if ceiling else None
        settings.apwcs_pct = _parse_float(request.form.get("apwcs_pct"), settings.apwcs_pct or 0.0)
        settings.ledger_from = _parse_date(request.form.get("ledger_from"))
        settings.source_notes = request.form.get("source_notes", "").strip()
        settings.updated_by_id = current_user.id
        settings.updated_at = datetime.utcnow()
        db.session.commit()
        flash("Payroll Tax Settings updated.", "success")
        return redirect(url_for("payroll.tax_settings"))

    # Bands grouped by pay frequency - see PayrollTaxBand's docstring: ZIMRA
    # publishes a genuinely different band table per frequency, so each one
    # gets its own table/add-form on the settings screen rather than one
    # flat list applied to everybody.
    bands_by_frequency = {
        f: PayrollTaxBand.query.filter_by(frequency=f).order_by(PayrollTaxBand.lower).all()
        for f in PAYROLL_PAY_FREQUENCIES
    }
    return render_template(
        "payroll/tax_settings.html", settings=settings, bands_by_frequency=bands_by_frequency,
        pay_frequencies=PAYROLL_PAY_FREQUENCIES, caveat=PAYROLL_TAX_CAVEAT,
    )


@payroll_bp.route("/tax-settings/band/add", methods=["POST"])
@login_required
def add_tax_band():
    _ensure_payroll_access()
    frequency = request.form.get("frequency", "Monthly")
    if frequency not in PAYROLL_PAY_FREQUENCIES:
        frequency = "Monthly"
    lower = _parse_float(request.form.get("lower"), 0.0)
    upper_raw = request.form.get("upper", "").strip()
    upper = _parse_float(upper_raw) if upper_raw else None
    rate_pct = _parse_float(request.form.get("rate_pct"), 0.0)
    band = PayrollTaxBand(
        frequency=frequency, lower=lower, upper=upper, rate_pct=rate_pct,
        order=PayrollTaxBand.query.filter_by(frequency=frequency).count(),
    )
    db.session.add(band)
    db.session.commit()
    flash(f"{frequency} PAYE band added.", "success")
    return redirect(url_for("payroll.tax_settings"))


@payroll_bp.route("/tax-settings/band/<int:band_id>/delete", methods=["POST"])
@login_required
def delete_tax_band(band_id):
    _ensure_payroll_access()
    band = PayrollTaxBand.query.get_or_404(band_id)
    db.session.delete(band)
    db.session.commit()
    flash("PAYE band removed.", "info")
    return redirect(url_for("payroll.tax_settings"))


# --------------------------------------------------------------- Employees

@payroll_bp.route("/employees")
@login_required
def list_employees():
    _ensure_payroll_access()
    scope = request.args.get("scope", "internal")
    _ensure_scope_access(scope)
    client_id = request.args.get("client_id", type=int)
    query = PayrollEmployee.query.filter_by(scope=scope)
    if scope == "client":
        query = restrict_to_visible_clients(query, PayrollEmployee.client_id)
    if scope == "client" and client_id:
        query = query.filter_by(client_id=client_id)
    employees = query.order_by(PayrollEmployee.is_active.desc(), PayrollEmployee.full_name).all()
    clients = visible_clients(current_user)
    selected_client = Client.query.get(client_id) if client_id else None
    return render_template(
        "payroll/employees.html", employees=employees, scope=scope,
        clients=clients, selected_client=selected_client,
    )


@payroll_bp.route("/employees/new", methods=["GET", "POST"])
@login_required
def new_employee():
    _ensure_payroll_access()
    scope = request.args.get("scope", request.form.get("scope", "internal" if can_see_internal_payroll() else "client"))
    _ensure_scope_access(request.form.get("scope", scope) if request.method == "POST" else scope)
    clients = visible_clients(current_user)
    staff_users = User.query.filter_by(is_active_flag=True).order_by(User.name).all()

    if request.method == "POST":
        scope = request.form.get("scope", "internal")
        if scope not in PAYROLL_SCOPES:
            scope = "internal"
        client_id = request.form.get("client_id") or None
        user_id = request.form.get("user_id") or None
        full_name = request.form.get("full_name", "").strip()

        if scope == "client" and not client_id:
            flash("Please select which client this employee belongs to.", "danger")
            return render_template("payroll/employee_form.html", scope=scope, clients=clients, staff_users=staff_users, employee=None)

        if scope == "internal" and user_id:
            linked_user = User.query.get(int(user_id))
            if linked_user and not full_name:
                full_name = linked_user.name

        if not full_name:
            flash("Please provide the employee's name.", "danger")
            return render_template("payroll/employee_form.html", scope=scope, clients=clients, staff_users=staff_users, employee=None)

        employee = PayrollEmployee(
            scope=scope,
            client_id=int(client_id) if scope == "client" and client_id else None,
            user_id=int(user_id) if scope == "internal" and user_id else None,
            full_name=full_name,
            employee_number=request.form.get("employee_number", "").strip() or None,
            national_id=request.form.get("national_id", "").strip() or None,
            job_title=request.form.get("job_title", "").strip() or None,
            nssa_number=request.form.get("nssa_number", "").strip() or None,
            bank_name=request.form.get("bank_name", "").strip() or None,
            bank_account_number=request.form.get("bank_account_number", "").strip() or None,
            pay_frequency=request.form.get("pay_frequency", "Monthly"),
            basic_salary=_parse_float(request.form.get("basic_salary"), 0.0),
            date_joined=_parse_date(request.form.get("date_joined")),
            notes=request.form.get("notes", "").strip(),
            created_by_id=current_user.id,
        )
        db.session.add(employee)
        db.session.commit()
        flash(f"Added {employee.full_name} to payroll.", "success")
        return redirect(url_for("payroll.list_employees", scope=scope, client_id=employee.client_id))

    preselect_client_id = request.args.get("client_id", type=int)
    return render_template(
        "payroll/employee_form.html", scope=scope, clients=clients, staff_users=staff_users,
        employee=None, preselect_client_id=preselect_client_id,
    )


@payroll_bp.route("/employees/<int:employee_id>/edit", methods=["GET", "POST"])
@login_required
def edit_employee(employee_id):
    _ensure_payroll_access()
    employee = PayrollEmployee.query.get_or_404(employee_id)
    _ensure_scope_access(employee.scope)
    clients = visible_clients(current_user)
    staff_users = User.query.filter_by(is_active_flag=True).order_by(User.name).all()

    if request.method == "POST":
        employee.full_name = request.form.get("full_name", "").strip() or employee.full_name
        employee.employee_number = request.form.get("employee_number", "").strip() or None
        employee.national_id = request.form.get("national_id", "").strip() or None
        employee.job_title = request.form.get("job_title", "").strip() or None
        employee.nssa_number = request.form.get("nssa_number", "").strip() or None
        employee.bank_name = request.form.get("bank_name", "").strip() or None
        employee.bank_account_number = request.form.get("bank_account_number", "").strip() or None
        employee.pay_frequency = request.form.get("pay_frequency", "Monthly")
        employee.basic_salary = _parse_float(request.form.get("basic_salary"), employee.basic_salary or 0.0)
        employee.date_joined = _parse_date(request.form.get("date_joined"))
        employee.date_left = _parse_date(request.form.get("date_left"))
        employee.is_active = bool(request.form.get("is_active"))
        employee.notes = request.form.get("notes", "").strip()
        if employee.scope == "internal":
            user_id = request.form.get("user_id") or None
            employee.user_id = int(user_id) if user_id else None
        db.session.commit()
        flash("Employee record updated.", "success")
        return redirect(url_for("payroll.list_employees", scope=employee.scope, client_id=employee.client_id))

    return render_template(
        "payroll/employee_form.html", scope=employee.scope, clients=clients, staff_users=staff_users,
        employee=employee,
    )


@payroll_bp.route("/employees/<int:employee_id>/delete", methods=["POST"])
@login_required
def delete_employee(employee_id):
    _ensure_payroll_access()
    employee = PayrollEmployee.query.get_or_404(employee_id)
    _ensure_scope_access(employee.scope)
    scope, client_id = employee.scope, employee.client_id
    if employee.payslips:
        # Preserve payroll history - deactivate rather than delete an
        # employee who already has at least one payslip on record.
        employee.is_active = False
        db.session.commit()
        flash(f"{employee.full_name} has payslip history, so was deactivated rather than deleted.", "info")
    else:
        db.session.delete(employee)
        db.session.commit()
        flash("Employee removed.", "info")
    return redirect(url_for("payroll.list_employees", scope=scope, client_id=client_id))


# --------------------------------------------------------------- Periods

@payroll_bp.route("/periods")
@login_required
def list_periods():
    _ensure_payroll_access()
    scope = request.args.get("scope", "internal")
    _ensure_scope_access(scope)
    client_id = request.args.get("client_id", type=int)
    query = PayrollPeriod.query.filter_by(scope=scope)
    if scope == "client":
        query = restrict_to_visible_clients(query, PayrollPeriod.client_id)
    if scope == "client" and client_id:
        query = query.filter_by(client_id=client_id)
    periods = query.order_by(PayrollPeriod.period_start.desc().nullslast(), PayrollPeriod.id.desc()).all()
    clients = visible_clients(current_user)
    selected_client = Client.query.get(client_id) if client_id else None
    return render_template(
        "payroll/periods.html", periods=periods, scope=scope, clients=clients, selected_client=selected_client,
    )


@payroll_bp.route("/periods/new", methods=["GET", "POST"])
@login_required
def new_period():
    _ensure_payroll_access()
    scope = request.args.get("scope", request.form.get("scope", "internal" if can_see_internal_payroll() else "client"))
    _ensure_scope_access(request.form.get("scope", scope) if request.method == "POST" else scope)
    clients = visible_clients(current_user)

    if request.method == "POST":
        scope = request.form.get("scope", "internal")
        if scope not in PAYROLL_SCOPES:
            scope = "internal"
        client_id = request.form.get("client_id") or None
        if scope == "client" and not client_id:
            flash("Please select which client this payroll period is for.", "danger")
            return render_template("payroll/period_form.html", scope=scope, clients=clients)

        name = request.form.get("name", "").strip()
        if not name:
            flash("Please give this payroll period a name (e.g. \"September 2026\").", "danger")
            return render_template("payroll/period_form.html", scope=scope, clients=clients)

        settings = _get_tax_settings()
        period = PayrollPeriod(
            scope=scope,
            client_id=int(client_id) if scope == "client" and client_id else None,
            name=name,
            period_start=_parse_date(request.form.get("period_start")),
            period_end=_parse_date(request.form.get("period_end")),
            pay_date=_parse_date(request.form.get("pay_date")),
            currency=settings.currency,
            created_by_id=current_user.id,
        )
        db.session.add(period)
        db.session.commit()
        flash(f"Payroll period \"{period.name}\" created - generate payslips below.", "success")
        return redirect(url_for("payroll.view_period", period_id=period.id))

    preselect_client_id = request.args.get("client_id", type=int)
    return render_template("payroll/period_form.html", scope=scope, clients=clients, preselect_client_id=preselect_client_id)


@payroll_bp.route("/periods/<int:period_id>")
@login_required
def view_period(period_id):
    _ensure_payroll_access()
    period = PayrollPeriod.query.get_or_404(period_id)
    _ensure_period_access(period)
    covered_employee_ids = {p.employee_id for p in period.payslips}
    eligible_query = PayrollEmployee.query.filter_by(scope=period.scope, is_active=True)
    if period.scope == "client":
        eligible_query = eligible_query.filter_by(client_id=period.client_id)
    pending_employees = [e for e in eligible_query.all() if e.id not in covered_employee_ids]
    med = None
    if period.scope == "internal" and period.payslips:
        import payroll_medical as pm
        from models import Supplier
        sup_default = pm.default_supplier()
        med = {"tot": pm.medical_lines(period), "posted": pm.posted_bills(period), "stale": pm.out_of_date(period), "supplier": sup_default,
               "suppliers": Supplier.query.order_by(Supplier.name).all(), "can_post": user_has_permission(current_user, "view_firm_finances")}
    ledger = None
    if period.scope == "internal" and period.payslips:
        import firm_payroll
        row = firm_payroll.row_for(period)
        ledger = {"posted": row is not None, "date": firm_payroll.period_date(period), "legs": firm_payroll.posting_preview(row) if row else [],
                  "from": firm_payroll.ledger_from(), "finalized": period.status == "Finalized",
                  "net_diff": bool(row and abs(row["net_stored"] - row["net"]) >= 0.01), "row": row}
    return render_template("payroll/period_detail.html", period=period, pending_employees=pending_employees, med=med, ledger=ledger)


@payroll_bp.route("/periods/<int:period_id>/medical-aid/post", methods=["POST"])
@login_required
def post_medical_aid(period_id):
    """Create the supplier bill(s) for the medical aid due to the society from this period's payslips (see payroll_medical.py)."""
    _ensure_payroll_access()
    period = PayrollPeriod.query.get_or_404(period_id)
    _ensure_period_access(period)
    if not user_has_permission(current_user, "view_firm_finances"):
        abort(403)
    import payroll_medical as pm
    from models import Supplier
    supplier = Supplier.query.get(request.form.get("supplier_id", type=int)) if request.form.get("supplier_id") else None
    made, err = pm.post_period(period, supplier, _parse_date(request.form.get("due_date")), request.form.getlist("part"), current_user)
    if err:
        db.session.rollback()
        flash(err, "danger")
        return redirect(url_for("payroll.view_period", period_id=period.id))
    settings = _get_tax_settings()
    settings.medical_aid_supplier_id = supplier.id
    db.session.commit()
    flash("Posted to Suppliers: " + "; ".join(f"{e.currency} {e.amount:,.2f} ({e.category})" for e in made) + f", owed to {supplier.name}. Pay it from the supplier's page.", "success")
    return redirect(url_for("payroll.view_period", period_id=period.id))


@payroll_bp.route("/periods/<int:period_id>/medical-aid/remove", methods=["POST"])
@login_required
def remove_medical_aid(period_id):
    _ensure_payroll_access()
    period = PayrollPeriod.query.get_or_404(period_id)
    _ensure_period_access(period)
    if not user_has_permission(current_user, "view_firm_finances"):
        abort(403)
    import payroll_medical as pm
    err = pm.remove_posted(period)
    if err:
        db.session.rollback()
        flash(err, "danger")
    else:
        db.session.commit()
        flash("The medical aid bill(s) were removed from Suppliers. You can post again.", "info")
    return redirect(url_for("payroll.view_period", period_id=period.id))


@payroll_bp.route("/periods/<int:period_id>/generate", methods=["POST"])
@login_required
def generate_payslips(period_id):
    _ensure_payroll_access()
    period = PayrollPeriod.query.get_or_404(period_id)
    _ensure_period_access(period)
    if period.status == "Finalized":
        flash("This period is finalized - reopen it before generating more payslips.", "danger")
        return redirect(url_for("payroll.view_period", period_id=period.id))

    settings = _get_tax_settings()
    # Bands are looked up PER EMPLOYEE below (by their own pay_frequency),
    # not fetched once here - see PayrollTaxBand's docstring: a Fortnightly
    # or Weekly employee must never be taxed against the Monthly table.
    # Cached per-frequency within this one request so a period with many
    # employees on the same frequency doesn't re-query per employee.
    bands_cache = {}

    def _bands_for(frequency):
        if frequency not in bands_cache:
            bands_cache[frequency] = PayrollTaxBand.query.filter_by(frequency=frequency).all()
        return bands_cache[frequency]

    covered_employee_ids = {p.employee_id for p in period.payslips}

    eligible_query = PayrollEmployee.query.filter_by(scope=period.scope, is_active=True)
    if period.scope == "client":
        eligible_query = eligible_query.filter_by(client_id=period.client_id)

    selected_ids = request.form.getlist("employee_id")
    employees = [e for e in eligible_query.all() if e.id not in covered_employee_ids]
    if selected_ids:
        selected_ids = {int(i) for i in selected_ids}
        employees = [e for e in employees if e.id in selected_ids]

    created = 0
    for employee in employees:
        bands = _bands_for(employee.pay_frequency)
        result = payroll_calc.calculate_payslip(employee.basic_salary, [], settings, bands)
        payslip = Payslip(
            period_id=period.id, employee_id=employee.id,
            generated_by_id=current_user.id, is_auto_calculated=True,
            **result,
        )
        db.session.add(payslip)
        created += 1
    db.session.commit()
    if created:
        flash(f"Generated {created} payslip(s).", "success")
    else:
        flash("No eligible employees left to generate payslips for.", "info")
    return redirect(url_for("payroll.view_period", period_id=period.id))


@payroll_bp.route("/periods/<int:period_id>/finalize", methods=["POST"])
@login_required
def finalize_period(period_id):
    _ensure_payroll_access()
    period = PayrollPeriod.query.get_or_404(period_id)
    _ensure_period_access(period)
    period.status = "Finalized" if period.status != "Finalized" else "Draft"
    db.session.commit()
    flash(f"Period marked {period.status}.", "success")
    return redirect(url_for("payroll.view_period", period_id=period.id))


@payroll_bp.route("/periods/<int:period_id>/backfill-apwcs", methods=["POST"])
@login_required
def backfill_apwcs(period_id):
    """Fill in APWCS on payslips that have none (e.g. generated before APWCS
    was added). Touches ONLY the informational apwcs figure - gross, taxable
    income, PAYE and net pay are never changed, and any payslip that already
    has a figure (including a manual one) is left alone - so it is safe on a
    finalized period too."""
    _ensure_payroll_access()
    period = PayrollPeriod.query.get_or_404(period_id)
    _ensure_period_access(period)
    settings = _get_tax_settings()
    pct = settings.apwcs_pct or 0.0
    if pct <= 0:
        flash("The APWCS rate in Payroll Tax Settings is 0% - set it first (the firm rate is 1.25% of Basic Salary), then backfill.", "danger")
        return redirect(url_for("payroll.view_period", period_id=period.id))
    fixed = 0
    for payslip in period.payslips_missing_apwcs:
        payslip.apwcs = round((payslip.basic_salary or 0.0) * pct / 100.0, 2)
        fixed += 1
    db.session.commit()
    if fixed:
        flash(f"APWCS calculated at {pct:g}% of Basic Salary on {fixed} payslip(s).", "success")
    else:
        flash("Every payslip in this period already has an APWCS figure.", "info")
    return redirect(url_for("payroll.view_period", period_id=period.id))


@payroll_bp.route("/periods/<int:period_id>/delete", methods=["POST"])
@login_required
def delete_period(period_id):
    _ensure_payroll_access()
    period = PayrollPeriod.query.get_or_404(period_id)
    _ensure_period_access(period)
    scope, client_id = period.scope, period.client_id
    db.session.delete(period)
    db.session.commit()
    flash("Payroll period deleted.", "info")
    return redirect(url_for("payroll.list_periods", scope=scope, client_id=client_id))


# --------------------------------------------------------------- Payslips

@payroll_bp.route("/payslips/<int:payslip_id>")
@login_required
def view_payslip(payslip_id):
    _ensure_payroll_access()
    payslip = Payslip.query.get_or_404(payslip_id)
    _ensure_payslip_access(payslip)
    timesheet_summary = _timesheet_summary_for(payslip.employee, payslip.period)
    # Annual/Vacation Leave is the one leave type the firm tracks a running
    # balance for (see leave_calc.sync_all_balances_for_employee) - shown on
    # the payslip so the employee can see the days they're accruing, same
    # current figures as the HR > Leave screen. Sick/Special/Maternity are
    # statutory provisions, not a balance, so they never appear here.
    leave_balances = leave_calc.sync_all_balances_for_employee(payslip.employee) if payslip.employee else []
    return render_template(
        "payroll/payslip_detail.html", payslip=payslip, item_categories=PAYSLIP_ITEM_CATEGORIES,
        timesheet_summary=timesheet_summary, leave_balances=leave_balances,
    )


@payroll_bp.route("/payslips/<int:payslip_id>/recalculate", methods=["POST"])
@login_required
def recalculate_payslip(payslip_id):
    _ensure_payroll_access()
    payslip = Payslip.query.get_or_404(payslip_id)
    _ensure_payslip_access(payslip)
    if payslip.period.status == "Finalized":
        flash("This payslip's period is finalized - reopen it first.", "danger")
        return redirect(url_for("payroll.view_payslip", payslip_id=payslip.id))

    settings = _get_tax_settings()
    # This employee's OWN pay-frequency bands - see PayrollTaxBand's
    # docstring on why a Fortnightly/Weekly employee can't use the Monthly
    # table.
    bands = PayrollTaxBand.query.filter_by(frequency=payslip.employee.pay_frequency).all()
    result = payroll_calc.calculate_payslip(payslip.basic_salary, payslip.items, settings, bands)
    for key, value in result.items():
        setattr(payslip, key, value)
    payslip.is_auto_calculated = True
    payslip.generated_at = datetime.utcnow()
    payslip.generated_by_id = current_user.id
    db.session.commit()
    flash("Payslip recalculated from current salary, line items and tax settings.", "success")
    return redirect(url_for("payroll.view_payslip", payslip_id=payslip.id))


@payroll_bp.route("/payslips/<int:payslip_id>/update", methods=["POST"])
@login_required
def update_payslip(payslip_id):
    _ensure_payroll_access()
    payslip = Payslip.query.get_or_404(payslip_id)
    _ensure_payslip_access(payslip)
    if payslip.period.status == "Finalized":
        flash("This payslip's period is finalized - reopen it first.", "danger")
        return redirect(url_for("payroll.view_payslip", payslip_id=payslip.id))

    payslip.basic_salary = _parse_float(request.form.get("basic_salary"), payslip.basic_salary or 0.0)
    payslip.exempt_income_total = _parse_float(request.form.get("exempt_income_total"), payslip.exempt_income_total or 0.0)
    payslip.taxable_income = _parse_float(request.form.get("taxable_income"), payslip.taxable_income or 0.0)
    payslip.gross_pay = _parse_float(request.form.get("gross_pay"), payslip.gross_pay or 0.0)
    payslip.paye_before_credits = _parse_float(request.form.get("paye_before_credits"), payslip.paye_before_credits or 0.0)
    payslip.tax_credits_total = _parse_float(request.form.get("tax_credits_total"), payslip.tax_credits_total or 0.0)
    payslip.paye_tax = _parse_float(request.form.get("paye_tax"), payslip.paye_tax or 0.0)
    payslip.aids_levy = _parse_float(request.form.get("aids_levy"), payslip.aids_levy or 0.0)
    payslip.nssa_employee = _parse_float(request.form.get("nssa_employee"), payslip.nssa_employee or 0.0)
    payslip.nssa_employer = _parse_float(request.form.get("nssa_employer"), payslip.nssa_employer or 0.0)
    payslip.apwcs = _parse_float(request.form.get("apwcs"), payslip.apwcs or 0.0)
    payslip.other_deductions_total = _parse_float(request.form.get("other_deductions_total"), payslip.other_deductions_total or 0.0)
    payslip.net_pay = _parse_float(request.form.get("net_pay"), payslip.net_pay or 0.0)
    payslip.notes = request.form.get("notes", "").strip()
    payslip.is_auto_calculated = False
    db.session.commit()
    flash("Payslip updated (marked as manually edited).", "success")
    return redirect(url_for("payroll.view_payslip", payslip_id=payslip.id))


@payroll_bp.route("/payslips/<int:payslip_id>/items/add", methods=["POST"])
@login_required
def add_payslip_item(payslip_id):
    _ensure_payroll_access()
    payslip = Payslip.query.get_or_404(payslip_id)
    _ensure_payslip_access(payslip)
    if payslip.period.status == "Finalized":
        flash("This payslip's period is finalized - reopen it first.", "danger")
        return redirect(url_for("payroll.view_payslip", payslip_id=payslip.id))

    label = request.form.get("label", "").strip()
    if not label:
        flash("Please describe the allowance/deduction.", "danger")
        return redirect(url_for("payroll.view_payslip", payslip_id=payslip.id))

    category = request.form.get("category", "Allowance")
    if category not in PAYSLIP_ITEM_CATEGORIES:
        category = "Allowance"
    # nssa_applicable only matters for Allowance/Exempt Income (the two
    # categories that feed NSSA Insurable Earnings - see
    # payroll_calc.calculate_payslip); defaults to True/"Yes" in the form
    # (unchanged NSSA behaviour) unless the firm explicitly picks "No" - the
    # one case this exists for is the EMPLOYER's own medical aid (or similar
    # benefit) contribution, which must be excluded from NSSA even though it
    # may still belong on the payslip.
    item = PayslipItem(
        payslip_id=payslip.id, category=category, label=label,
        amount=_parse_float(request.form.get("amount"), 0.0),
        taxable=bool(request.form.get("taxable")) if category == "Allowance" else False,
        nssa_applicable=bool(request.form.get("nssa_applicable", "1")) if category in ("Allowance", "Exempt Income") else True,
        medical_aid=(request.form.get("medical_aid") if request.form.get("medical_aid") in ("employee", "employer") and category != "Tax Credit" else None),
    )
    db.session.add(item)
    db.session.commit()
    flash(f"{category} added - click Recalculate to reflect it in the totals.", "success")
    return redirect(url_for("payroll.view_payslip", payslip_id=payslip.id))


@payroll_bp.route("/payslips/items/<int:item_id>/delete", methods=["POST"])
@login_required
def delete_payslip_item(item_id):
    _ensure_payroll_access()
    item = PayslipItem.query.get_or_404(item_id)
    _ensure_payslip_access(item.payslip)
    payslip_id = item.payslip_id
    if item.payslip.period.status == "Finalized":
        flash("This payslip's period is finalized - reopen it first.", "danger")
        return redirect(url_for("payroll.view_payslip", payslip_id=payslip_id))
    db.session.delete(item)
    db.session.commit()
    flash("Line item removed - click Recalculate to reflect it in the totals.", "info")
    return redirect(url_for("payroll.view_payslip", payslip_id=payslip_id))


@payroll_bp.route("/payslips/<int:payslip_id>/delete", methods=["POST"])
@login_required
def delete_payslip(payslip_id):
    _ensure_payroll_access()
    payslip = Payslip.query.get_or_404(payslip_id)
    _ensure_payslip_access(payslip)
    period_id = payslip.period_id
    if payslip.period.status == "Finalized":
        flash("This payslip's period is finalized - reopen it first.", "danger")
        return redirect(url_for("payroll.view_payslip", payslip_id=payslip.id))
    db.session.delete(payslip)
    db.session.commit()
    flash("Payslip deleted.", "info")
    return redirect(url_for("payroll.view_period", period_id=period_id))


@payroll_bp.route("/payslips/<int:payslip_id>/download/docx")
@login_required
def download_payslip_docx(payslip_id):
    _ensure_payroll_access()
    payslip = Payslip.query.get_or_404(payslip_id)
    _ensure_payslip_access(payslip)
    leave_balances = leave_calc.sync_all_balances_for_employee(payslip.employee) if payslip.employee else []
    buf = payroll_documents.generate_payslip_docx(payslip, leave_balances=leave_balances)
    filename = f"Payslip_{payslip.employee.full_name.replace(' ', '_')}_{payslip.period.name.replace(' ', '_')}.docx"
    return send_file(
        buf, as_attachment=True, download_name=filename,
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    )


@payroll_bp.route("/payslips/<int:payslip_id>/download/pdf")
@login_required
def download_payslip_pdf(payslip_id):
    _ensure_payroll_access()
    payslip = Payslip.query.get_or_404(payslip_id)
    _ensure_payslip_access(payslip)
    leave_balances = leave_calc.sync_all_balances_for_employee(payslip.employee) if payslip.employee else []
    buf = payroll_documents.generate_payslip_pdf(payslip, leave_balances=leave_balances)
    filename = f"Payslip_{payslip.employee.full_name.replace(' ', '_')}_{payslip.period.name.replace(' ', '_')}.pdf"
    return send_file(buf, as_attachment=True, download_name=filename, mimetype="application/pdf")
