import os
import sys


def _is_frozen():
    return getattr(sys, "frozen", False)


if _is_frozen():
    # Running as a PyInstaller-built .exe.
    # Bundled read-only resources (templates/css) live in the temp extraction dir.
    RESOURCE_DIR = getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
    # Writable data (database, uploads) must live next to the .exe, not in the
    # temp extraction dir, so it survives between runs.
    DATA_DIR = os.path.dirname(os.path.abspath(sys.executable))
else:
    RESOURCE_DIR = os.path.abspath(os.path.dirname(__file__))
    DATA_DIR = RESOURCE_DIR

# Cloud hosting (e.g. Render) override: the app's code is redeployed fresh from
# git on every deploy, so writable data (database, uploads, editable document
# templates) must live on a separate persistent disk instead of next to the
# code. Set the DATA_DIR environment variable to that disk's mount path (e.g.
# "/var/data") in the hosting platform's dashboard to enable this. Local/.exe
# installs never set this, so their behaviour above is unchanged.
if os.environ.get("DATA_DIR"):
    DATA_DIR = os.environ["DATA_DIR"]

INSTANCE_DIR = os.path.join(DATA_DIR, "instance")
UPLOAD_DIR = os.path.join(DATA_DIR, "uploads")
TEMPLATE_DIR = os.path.join(RESOURCE_DIR, "templates")
STATIC_DIR = os.path.join(RESOURCE_DIR, "static")
# Read-only originals shipped with the app - only ever read from, used once to
# seed DOCUMENT_TEMPLATES_DATA_DIR below. Never written to (it's inside the
# read-only bundle when running as a frozen .exe).
DOCUMENT_TEMPLATES_SEED_DIR = os.path.join(RESOURCE_DIR, "document_templates")
# Writable, editable copy that the app actually serves downloads from and
# that the in-app Edit/New/Delete Document Templates screens modify. Lives
# next to the database/uploads so it survives updates and edits persist.
DOCUMENT_TEMPLATES_DATA_DIR = os.path.join(DATA_DIR, "document_templates_data")
# Backwards-compatible alias (older code referenced this name for the
# read-only bundled copy).
DOCUMENT_TEMPLATES_DIR = DOCUMENT_TEMPLATES_SEED_DIR
# Writable folder for the HR & Administration > Policies and Procedures
# library (firm policies, procedures, forms) - same idea as
# DOCUMENT_TEMPLATES_DATA_DIR above, but there's no bundled/seeded starting
# set; it starts empty and admins/partners add files from the app.
POLICIES_DATA_DIR = os.path.join(DATA_DIR, "policies_data")
# Writable folder for the Regulatory Notices library (RBZ and FIU Zimbabwe
# adverse-notice PDFs the firm uploads itself, since neither regulator
# publishes a searchable/machine-readable list) - same idea as
# POLICIES_DATA_DIR above: starts empty, admins/partners add files from the
# app, and the extracted text of each PDF is what Sanctions & Adverse
# Notice Screening searches during an auto-screen.
REGULATORY_NOTICES_DATA_DIR = os.path.join(DATA_DIR, "regulatory_notices_data")
# Writable folder for company registration documents uploaded against a
# Client (certificate of incorporation, CR14, share register, etc - see
# models.CompanyDocument and company_documents.py) - same idea as
# POLICIES_DATA_DIR/REGULATORY_NOTICES_DATA_DIR above: starts empty, any
# team member with the "Manage Company Documents" permission adds files
# from the app.
COMPANY_DOCUMENTS_DATA_DIR = os.path.join(DATA_DIR, "company_documents_data")
# Writable folder for each Client's own logo (see models.Client.logo_filename)
# - used on the Financial Statements cover page. Same idea as
# COMPANY_DOCUMENTS_DATA_DIR above: starts empty, one image per client,
# replaced (not accumulated) whenever a new logo is uploaded.
CLIENT_LOGOS_DATA_DIR = os.path.join(DATA_DIR, "client_logos_data")


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "neverlank-dev-secret-change-me")
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", f"sqlite:///{os.path.join(INSTANCE_DIR, 'neverlank.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = UPLOAD_DIR
    MAX_CONTENT_LENGTH = 25 * 1024 * 1024  # 25 MB per upload
    ALLOWED_EXTENSIONS = {
        "pdf", "doc", "docx", "xls", "xlsx", "csv", "png", "jpg", "jpeg", "txt", "zip", "pptx"
    }
    TEMPLATE_FOLDER = TEMPLATE_DIR
    STATIC_FOLDER = STATIC_DIR
    DOCUMENT_TEMPLATES_SEED_DIR = DOCUMENT_TEMPLATES_SEED_DIR
    DOCUMENT_TEMPLATES_DATA_DIR = DOCUMENT_TEMPLATES_DATA_DIR
    DOCUMENT_TEMPLATES_DIR = DOCUMENT_TEMPLATES_DIR
    POLICIES_DATA_DIR = POLICIES_DATA_DIR
    REGULATORY_NOTICES_DATA_DIR = REGULATORY_NOTICES_DATA_DIR
    COMPANY_DOCUMENTS_DATA_DIR = COMPANY_DOCUMENTS_DATA_DIR
    CLIENT_LOGOS_DATA_DIR = CLIENT_LOGOS_DATA_DIR
