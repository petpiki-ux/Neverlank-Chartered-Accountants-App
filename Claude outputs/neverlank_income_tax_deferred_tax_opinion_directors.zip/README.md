# Income Tax & Deferred Tax Computation, Audit Opinion, Directors' Statement, client logo cover page

## What you asked for

> "I want to add Income Tax Computation Tab…. Also Deferred Tax Computation Tab….Movement Schedule must be note for PPE … at the bottom of PPE note show line linking Closing balance to TB and calculating differences if any that will be basis for adjustment….on client onboarding we put client logo for Financial Statements Cover page…. For Assurance engagement financial statements must come Audit opinion so need Audit Opinion Tab …. Financial Statements page after cover page must have Client Details and Table of contents…. Financial Statements must also have directors statement with provision for 2 directors signatures"

Seven things, all delivered in this package. On the one open question - whether the Audit Opinion tab should only appear for Audit engagements, or Assurance too, and with what wording - you said **"Audit and Assurance both, one flexible tab"**, so that's exactly what's built: one tab, a report-basis picker, and wording that switches with it.

## What changed

### 1. Income Tax Computation (new tab)

A new **Income Tax Computation** tab on every engagement. It takes accounting profit before tax straight from the Statement of Profit or Loss (never re-typed), and reconciles it to taxable income and the current tax charge through a table of add-back / allowable-deduction / capital-allowance lines you add, edit, and delete in place.

The corporate tax rate and AIDS levy rate are **left blank for you to enter** - I checked two current sources for Zimbabwe's rate while building this and they disagreed with each other (one said the corporate rate "remains at 25%", another said "24%" with a combined effective rate of "24.72%" once a 3% AIDS levy is applied), so rather than guess and bake in a number that might be wrong, the app leaves both fields empty and computes a **nil tax charge** until you supply them - never a fabricated statutory figure. Whatever you were already using for prior tax computations is what belongs here.

At the foot of the computation, a trial balance reconciliation line always shows the computed tax charge against whatever your trial balance actually records as Income Tax Expense, and calls out any difference as the basis for a proposed adjustment - never silently absorbed either way. Standard 3-tier sign-off (prepared / reviewed / partner sign-off), same as everywhere else in the app.

### 2. Deferred Tax Computation (new tab)

A new **Deferred Tax Computation** tab, nets every temporary difference (accounting amount vs. tax base) into a single deferred tax asset or liability at whichever tax rate you enter. Property, plant and equipment - almost always the most material temporary difference - has its accounting side pulled **live** from the PPE Asset Register's own movement schedule (added last round); you only supply its tax base (the cumulative tax written-down value), since the app has no prior-year capital allowance history to work that out on its own. Every other temporary difference (provisions, unrealised amounts, unrecognised assessed losses, etc.) is a plain editable table, same pattern as everywhere else.

Same trial-balance reconciliation line at the foot, this time against your trial balance's net deferred tax liability/(asset), and the same 3-tier sign-off.

### 3. PPE note: reconciliation line now always shown

Previously, the "Per trial balance... Per Asset Register..." line at the foot of the PPE note only appeared when the two genuinely disagreed. It's now **always** shown, on both years, whether they tie out or not - consistent with the two new tax reconciliations above, and so the note always documents that the check was actually done, not just when it turned something up.

### 4. Client logo → Financial Statements cover page

The Client detail page (Clients > a client) now has a **Client logo** card - upload a PNG or JPG once at onboarding (or any time), replace it, or remove it. It's used only on that client's Financial Statements cover page (see #6 below); nothing else in the app uses it. No logo uploaded yet renders cleanly with no image, nothing broken.

### 5. Audit Opinion / Review Report (new tab, Audit + Assurance)

A new **Audit Opinion / Review Report** card on the Finalisation tab, shown for both Audit and Assurance engagement types (per your answer above) - one flexible tab, not two separate ones. You pick:

- **Report basis** - Audit opinion (ISA 700) or Review / limited assurance conclusion (ISRE 2400)
- **Modification** - Unmodified, Qualified, Adverse, or Disclaimer

"Regenerate wording" rebuilds all four report paragraphs (Opinion, Basis for Opinion, Directors' Responsibility, Auditor's/Reviewer's Responsibility) as a fresh starting draft for whatever basis/modification is currently selected - genuine ISA 700 / ISRE 2400 boilerplate, adjusted for the basis and modification, with a bracketed placeholder for you to describe the actual matter on anything other than an unmodified opinion (never invented). Every paragraph stays fully editable afterwards - same "system drafts, you tailor" pattern as the rest of the app. Only a **Partner sign-off** actually issues the report; saving or regenerating always resets any existing review/sign-off, since a changed draft needs re-review.

### 6. Financial Statements cover page + Client Details/Table of Contents page

The generated Financial Statements Word document now opens with:

1. **Cover page** - the client's own logo (if uploaded, #4 above), the client's name, "Financial Statements", and "for the year ended [period end]" - the client's identity, not the firm's.
2. **Client Details & Table of Contents page** - registered name, company registration number, registered address, industry, the confirmed directors and company secretary (from the client's Directors & Shareholders list), and the auditors; then a table of contents listing every section that follows.

The firm's own letterhead (as before) now appears on its own page after these two, ahead of the primary statements.

### 7. Directors' Statement (new card, every engagement)

A **Directors' Statement** card on the Finalisation tab - standard responsibility-statement wording (fully editable), two director name/title fields, and a statement date. "Use directors on file" pulls the names straight from the client's confirmed Directors & Shareholders list; a manual save lets you override with a different title (e.g. "Managing Director") than what's recorded there. In the generated Word document it appears right after the Client Details/Table of Contents page (before the Audit Opinion, if any) with an actual **two-signature table** - one column per director, a signature line, their name, and their title.

## What was tested

New `smoke_test29` (123 checks): every feature above, end to end - `default_audit_opinion_paragraphs()` for both bases across all four modifications; `build_income_tax_computation()`'s add-back/deduction/loss-carry-forward arithmetic and its deliberate nil result with no rate supplied; `build_deferred_tax_computation()`'s asset/liability/nil classification; the full Flask flow for client logo upload (including a rejected non-image upload), Income Tax and Deferred Tax line/item CRUD and their reconciliations, Directors' Statement save and "use directors on file", Audit Opinion save/regenerate/review/partner-sign for both an audit and a (regenerated) qualified review report, the cross-preparer review/sign-off restrictions, an Assurance engagement getting the same tab, a Consulting engagement correctly *not* getting it, and the generated Word document's cover page, Client Details/TOC page, Directors' Statement signature table, and Independent Reviewer's Report section. The full pre-existing regression suite (`smoke_test16` through `smoke_test28`, 769 checks) was re-run and still passes in full.

**Total: 892 checks, 0 failed.**

## How to apply this update

Same as always - [GitHub Desktop](https://desktop.github.com/) (or plain `git`), repository already cloned.

**Option A - copy the files (simplest):**

1. Unzip this package.
2. Copy everything inside `files/` into your repository, keeping the same folder structure (`templates/clients/detail.html` goes into `templates/clients/`, `templates/engagements/detail.html` into `templates/engagements/`, the rest into the repository root).
3. In GitHub Desktop, review the changed files, commit, and push.

**Option B - apply the patch with git:**

```
git am 0001-Add-Income-Tax-and-Deferred-Tax-Computation-tabs-Aud.patch
git push
```

No database migration step is needed - the new tables (Directors' Statement, Audit Opinion, Income Tax Computation and its lines, Deferred Tax Computation and its items) are created automatically the next time the app starts, and the one new column on an existing table (`Client.logo_filename`) is added automatically too, the same lightweight way every earlier round has worked.

## Files changed

- `models.py` - `Client.logo_filename`; `DirectorsStatement`; `AuditOpinion` plus its basis/modification constants; `IncomeTaxComputation`/`IncomeTaxAdjustmentLine` plus item-type constants; `DeferredTaxComputation`/`DeferredTaxItem`.
- `financials.py` - `DEFAULT_DIRECTORS_STATEMENT_TEXT`; `default_audit_opinion_paragraphs()`; `build_income_tax_computation()`; `build_deferred_tax_computation()`; `build_notes()` now always populates the PPE note's trial-balance reconciliation.
- `config.py` - `CLIENT_LOGOS_DATA_DIR`.
- `clients.py` - client logo upload/remove/serve routes.
- `engagements.py` - routes for Directors' Statement, Audit Opinion (save/regenerate/review/sign-off), Income Tax Computation (settings, lines CRUD, review/sign-off), Deferred Tax Computation (settings, items CRUD, review/sign-off); the new context gathered for the Finalisation/Income Tax/Deferred Tax tabs; the Financial Statements generation route extended to pass the Directors' Statement, Audit Opinion, and confirmed client key people through to the Word document builder.
- `workpapers.py` - the cover page, Client Details/Table of Contents page, Directors' Statement section (with its two-column signature table), and Independent Auditor's/Reviewer's Report section, all in `build_financial_statements_docx()`.
- `templates/clients/detail.html` - the Client logo card.
- `templates/engagements/detail.html` - the Income Tax Computation and Deferred Tax Computation tabs; the Directors' Statement and Audit Opinion / Review Report cards on the Finalisation tab; the PPE note's reconciliation line now always rendered.
