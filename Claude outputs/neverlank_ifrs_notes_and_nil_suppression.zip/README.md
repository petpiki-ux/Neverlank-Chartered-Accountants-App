# Numbered IFRS / IFRS for SMEs Notes to the Financial Statements, and nil-balance suppression

## What you asked for

> "On Finalisation I want Financial Statements with Notes for Companies that Prepare According to IFRS use the attached template..... in the financial Statements dont show Nil Balances (If account has nil Balance both current year and Prior year)"

...followed by:

> "Use the attached for IFRS for SMEs"

You attached two templates: the Deloitte **IFRS Illustrative Financial Statements 2025** (190 pages) and the PKF **IFRS for SMEs Illustrative Financial Statements**. Before building anything I asked you two questions and you confirmed:

1. Notes scope: accounting policies + a numbered breakdown note per Statement of Financial Position/Profit or Loss line + the standard closing notes (related party, contingencies and commitments, events after the reporting period).
2. How to switch a client between frameworks: a new "Financial reporting framework" field on the engagement itself (Full IFRS / IFRS for SMEs / Other-local GAAP).

## What changed

### 1. A "Financial reporting framework" setting per engagement

Every engagement now has a **Financial reporting framework** dropdown (Basis of preparation & sign-off, on the Finalisation tab): **Full IFRS**, **IFRS for SMEs**, or **Other / local GAAP**. New and existing engagements default to **Full IFRS**, so nothing changes for you until you look at this dropdown and pick something else.

### 2. Full IFRS and IFRS for SMEs get numbered Notes to the Financial Statements

Choose either of these two frameworks and the Finalisation tab now builds, straight from your trial balance, the notes structure both templates use:

- **Note 1 - General information**: entity name, registered office and principal activity, pulled from the Entity Details you already have on file.
- **Note 2 - Basis of preparation**: the compliance wording differs between Full IFRS and IFRS for SMEs (a sensible default is filled in; you can edit it).
- **Note 3 - Significant accounting policies**: a policy paragraph for each category that has one on your trial balance (revenue recognition, PPE, financial instruments, provisions, trade receivables/payables, etc).
- **Note 4 onward - one breakdown note per Statement of Financial Position / Profit or Loss line actually used**, e.g. "5. Trade and other receivables", listing the individual GL accounts making up that total and the note number is now shown against the matching line on the face of the statements, so a reader can cross-reference exactly like they would in a real audited set of accounts.
- **The last three notes are always**: related party transactions, contingencies and commitments, and events after the reporting period - free text, each with a sensible placeholder if you leave it blank.

A category with a nil balance in both years - current and prior - gets **no note at all**, the same way it's now hidden on the face (see below), so you never end up with an empty note referencing a line that isn't shown.

Full IFRS and IFRS for SMEs share one note-building engine and differ only in Note 2's wording. This was a scope call I made rather than one you separately confirmed: your trial balance only ever carries one net current/prior balance per account (there's no movement-schedule data - opening balance, additions, disposals, transfers - for things like PPE or intangibles), so the more elaborate disclosures in the two 190-and-40-page templates (hedge accounting, joint ventures, insurance contracts, detailed PPE/intangible asset movement tables, deferred tax reconciliations, and similar) are out of scope for both frameworks by design, not just for IFRS for SMEs. If you need any of those in a specific engagement, they'd need to go in as free text for now.

**Other / local GAAP is completely unaffected** - it keeps the plain statements and the single free-text notes box exactly as before. Nothing changes for those engagements unless you deliberately switch the dropdown.

### 3. Nil balances no longer clutter any financial statement

Independently of the framework (this applies to every engagement, IFRS or not), a line item is now hidden from the Statement of Profit or Loss, Statement of Financial Position, Statement of Changes in Equity, and the investing/financing sections of the Cash Flow Statement whenever its balance is zero in **both** the current and prior year - matching what you asked for.

A few things this deliberately does **not** touch, so the statements still balance and still make sense:
- Subtotals and totals (Gross profit, Total assets, Net cash movement, etc.) are always calculated from the full, unfiltered trial balance - hiding a nil row never changes a total.
- Bold/subtotal rows, and **Retained earnings** specifically, are never hidden even if they happen to be nil, since a reader expects to always see them.
- The Cash Flow Statement's operating activities and working-capital reconciliation lines are left as a fixed set - that section is a reconciliation, not a list of accounts, so hiding a zero line there would make it harder to follow rather than easier.

### 4. The generated Word workpaper carries all of this through

Downloading the financial statements as a Word document (Generate Document on the Finalisation tab) now produces the same numbered notes and the same nil suppression as what you see on screen - it's built from the same underlying data, so there's nothing extra to keep in sync.

## What was tested

- A new automated test (`smoke_test26`, 49 checks) covers: note generation and numbering, nil accounts producing no note and no face line (while non-nil accounts in the same category still do), the framework dropdown switching an engagement between Full IFRS, IFRS for SMEs, and Other and the page changing correctly each time (including Other completely hiding the numbered notes), and the generated Word document containing the same notes and figures.
- The full existing regression suite (`smoke_test16` through `smoke_test25`, 573 checks covering everything built in prior rounds - entity details, payroll, workpaper generation, tickmarks, the Filing Index, trial balance import and mapping, analytical review) was re-run and still passes in full.
- **Total: 622 checks, 0 failed.**

This was not tested against your real trial balance file, since this round doesn't change how the trial balance is imported or mapped (that was Rounds C and D) - it only changes how the already-mapped balances are presented in the financial statements. The same trial balance you're already using will work as-is; just set the Financial reporting framework on the engagement to see the new notes.

## How to apply this update

You'll need [GitHub Desktop](https://desktop.github.com/) (or plain `git`) with your `Neverlank-Chartered-Accountants-App` repository already cloned, exactly as with the last two updates.

**Option A - copy the files (simplest):**

1. Unzip this package.
2. Copy everything inside `files/` into your repository, keeping the same folder structure (`templates/engagements/detail.html` goes into your `templates/engagements/` folder, the rest go into the repository root).
3. In GitHub Desktop, review the changed files, write a commit message (or use the one below), and commit.
4. Push to GitHub. Render will redeploy automatically.

**Option B - apply the patch with git:**

```
git am 0001-Add-numbered-IFRS-IFRS-for-SMEs-Notes-to-the-Financi.patch
git push
```

This applies the commit with its full message and authorship already attached, so you don't need to write your own commit message.

## Files changed

- `app.py` - lightweight auto-migration: adds `reporting_framework` to `engagement`, and `related_party_note` / `commitments_note` / `subsequent_events_note` to `financial_statements`.
- `models.py` - new `REPORTING_FRAMEWORKS` setting and the three new note fields.
- `financials.py` - nil-balance suppression across all four statements, and the new numbered notes engine.
- `engagements.py` - wires the framework selector and notes into the Finalisation tab and the save action.
- `templates/engagements/detail.html` - the Notes to the Financial Statements card, the Note column on the SFP/PL, and the Financial reporting framework dropdown with its extra note fields.
- `workpapers.py` - the same notes structure and nil suppression carried through to the generated Word document.
