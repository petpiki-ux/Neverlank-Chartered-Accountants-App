# Auto-suggested SME Act size band from entered turnover/assets/headcount

**Apply this after the "Continuous statement tables..." update from earlier today** - it builds on the same files (Company classification card, Cash Flow methods, etc.) and assumes that update is already in place.

## What you asked for

After the Company classification card shipped earlier today, you sent a screenshot of a Google search result giving the general Zimbabwean Small and Medium Enterprises Act size thresholds:

| Category | Staff Headcount | Max Annual Turnover | Max Gross Assets (Excl. Real Estate) |
|---|---|---|---|
| Micro | ≤ 5 | ≤ US$30,000 | US$10,000 – US$30,000 |
| Small | 6 to 30/40 | ≤ US$500,000 | US$250,000 – US$500,000 |
| Medium | 31 to 75/100 | US$1,000,000 | US$500,000 – US$1,000,000 |

captioned "Criteria for grouping companies in Zimbabwe." I asked how you wanted this used, and you chose **auto-classify from entered figures**, with the preparer still able to see and override the result.

## What changed

The Company classification card (Finalisation tab) now has three new fields, right below the sector dropdown:

- **Staff headcount**
- **Annual turnover (US$)**
- **Gross assets, excl. real estate (US$)**

Enter all three and the app shows a suggestion - "Suggested band based on the figures above: **Small**" (or Micro/Medium/Large) - next to the existing Size band dropdown. A collapsible reference table shows the exact thresholds used, so you can see why. The dropdown itself is completely unchanged: it's still the preparer's own selection that gets saved as the entity's classification, and the suggestion never overwrites it on its own - you can always pick a different band than the one suggested.

Two judgment calls worth being upfront about:

- Your table gave headcount as ranges ("6 to 30/40" for Small, "31 to 75/100" for Medium) rather than single numbers, since the Act's actual Fourth Schedule varies these slightly by sector and your table was a general summary across sectors. I used the **higher** number in each range (40 and 100) as the ceiling, so a company isn't understated into a smaller band than its own sector might actually allow.
- An entity only qualifies for a band if it meets **every** one of that band's thresholds (headcount, turnover, and assets); if it exceeds even one, it's bumped up to the next band. This is the standard, conservative way this kind of multi-criteria classification is normally applied.

Both are flagged directly in the app (the reference table's caption, and the code comments) as a general approximation, not a substitute for checking the actual sector-specific schedule on a genuinely borderline case.

## What was tested

Extended `smoke_test27` (71 checks, up from 59): unit tests for `classify_sme_size()` at each threshold boundary (micro/small/medium/large, and confirming a single figure exceeding a threshold bumps the whole classification up), plus an end-to-end check that entering figures on the Finalisation tab, saving, and reloading shows the correct suggested band. The full existing regression suite (`smoke_test16` through `smoke_test26`, 622 checks) was re-run and still passes in full.

**Total: 693 checks, 0 failed.**

## How to apply this update

Same as always - apply the earlier "Continuous statement tables..." update first if you haven't already, then this one on top.

**Option A - copy the files (simplest):**

Unzip this package and copy everything inside `files/` into your repository (same folder structure as before), then commit and push in GitHub Desktop.

**Option B - apply the patch with git:**

```
git am 0001-Auto-suggest-a-Small-and-Medium-Enterprises-Act-size.patch
git push
```

## Files changed

- `financials.py` - `SME_ACT_SIZE_THRESHOLDS` and `classify_sme_size()`.
- `models.py` - new Engagement fields (`sme_annual_turnover`, `sme_gross_assets`, `sme_staff_headcount`).
- `app.py` - lightweight auto-migration for the three new columns.
- `engagements.py` - parses the three new form fields on save, computes the suggested band for display.
- `templates/engagements/detail.html` - the three new input fields, the reference threshold table, and the suggestion text.
